class DefinitionsController < ApplicationController
	before_filter :authorize, only: [:new,:upvote,:downvote]
	def show
		@flag ="1"

		if @word = Word.find_by_name(params[:name])
           @defs = Definition.where(word_id: @word.id)
           @comments = Comment.all
        else
        	@flag = "0"
        end
	end
	
	def new
	end

	def create #associative creation of word and defintion through user addition

		if word =  Word.find_by_name(params[:word])
			word.save
		else
		    word = Word.new(name: params[:word])
		    word.save
		end
		definition = Definition.new(description: params[:desc], likes: 0, dislikes: 0, word_id: word.id, user_id: current_user.id )
        if definition.save
		   redirect_to "/glossary"
		else
		   redirect_to "/addDef"
		end
	end

	def upvote
		@definition = Definition.find(params[:id])
		@definition.upvote_from current_user
		redirect_to "/glossary"
	end

	def downvote
		@definition = Definition.find(params[:id])
		@definition.downvote_from current_user
		redirect_to "/glossary"
	end
	
end
