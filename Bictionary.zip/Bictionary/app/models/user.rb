class User < ActiveRecord::Base
	acts_as_voter
	has_secure_password 
	has_many :definitions
	has_many :words, through: :definitions

    validates :uname, presence: true, uniqueness: true
    validates :email, presence: true, uniqueness: true, format: { with: /[a-zA-Z0-9._-]+@+[a-zA-Z0-9._-]+\.+[a-zA-Z]/} 
    


end
