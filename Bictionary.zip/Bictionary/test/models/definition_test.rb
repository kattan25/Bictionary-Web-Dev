require 'test_helper'

class DefinitionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
