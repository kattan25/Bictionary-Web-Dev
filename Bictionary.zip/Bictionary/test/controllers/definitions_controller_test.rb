require 'test_helper'

class DefinitionsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
